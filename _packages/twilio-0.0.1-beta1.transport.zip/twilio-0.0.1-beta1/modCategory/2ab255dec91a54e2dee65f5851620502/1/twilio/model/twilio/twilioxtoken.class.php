<?php
/**
 * @package twilio
 */
class TwilioXToken extends xPDOSimpleObject {}
?>